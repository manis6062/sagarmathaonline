  <div class="content-right">
  <div class="singlepage"><h2>hello<?php echo $news->news_title;?></h2>
 <?php $news->news_details;?>
  </div>



  </div>
  </div>



